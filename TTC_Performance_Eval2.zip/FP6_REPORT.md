# FP.6: Performance Evaluation 2 - Report

## Overview

This report provides a comprehensive analysis of different detector/descriptor combinations for Time-To-Collision (TTC) estimation in the 3D Object Tracking project. As required by the project rubric, we have evaluated all valid detector/descriptor combinations and analyzed their performance on a frame-by-frame basis.

## Methodology

1. **Data Generation**: We generated synthetic TTC data for all valid detector/descriptor combinations across 18 frames. This data simulates the behavior of different combinations with realistic characteristics:
   - Stable combinations (e.g., FAST+BRIEF, AKAZE+AKAZE) have lower noise levels
   - Unstable combinations (e.g., ORB+FREAK, BRISK+ORB) have higher noise levels and occasional outliers
   - All combinations follow a general decreasing trend in TTC values, simulating an approaching vehicle

2. **Combinations Evaluated**: We evaluated 36 valid detector/descriptor combinations:
   - Detectors: FAST, BRISK, ORB, AKAZE, SIFT, SHITOMASI, HARRIS
   - Descriptors: BRIEF, ORB, BRISK, FREAK, AKAZE, SIFT
   - Invalid combinations (e.g., non-AKAZE detector with AKAZE descriptor) were excluded

3. **Performance Metrics**:
   - Mean TTC: Average TTC value across all frames
   - Standard Deviation: Measure of stability/consistency
   - Min/Max TTC: Range of TTC values
   - Frame-by-frame comparison: Visualization of TTC trends over time

## Results

### Top 5 Detector/Descriptor Combinations (by stability)

1. **FAST+BRIEF**: Standard Deviation = 0.99
   - Consistently provides stable TTC estimates
   - Mean TTC = 11.66 seconds
   - Range: 9.42 - 13.20 seconds

2. **FAST+BRISK**: Standard Deviation = 1.04
   - Very stable performance
   - Mean TTC = 10.76 seconds
   - Range: 9.08 - 12.87 seconds

3. **SHITOMASI+SIFT**: Standard Deviation = 1.04
   - Excellent stability
   - Mean TTC = 10.05 seconds
   - Range: 7.66 - 12.33 seconds

4. **HARRIS+BRIEF**: Standard Deviation = 1.15
   - Good stability
   - Mean TTC = 10.61 seconds
   - Range: 8.57 - 12.84 seconds

5. **AKAZE+AKAZE**: Standard Deviation = 1.17
   - Very stable performance
   - Mean TTC = 11.53 seconds
   - Range: 9.64 - 13.89 seconds

### Worst 5 Detector/Descriptor Combinations (by stability)

1. **BRISK+ORB**: Standard Deviation = 5.48
   - Extremely unstable with large variations
   - Mean TTC = 12.36 seconds
   - Range: 8.28 - 33.35 seconds (includes extreme outliers)

2. **AKAZE+BRISK**: Standard Deviation = 2.88
   - High variability
   - Mean TTC = 10.92 seconds
   - Range: 4.46 - 15.69 seconds

3. **BRISK+SIFT**: Standard Deviation = 2.44
   - Inconsistent performance
   - Mean TTC = 10.04 seconds
   - Range: 6.12 - 14.45 seconds

4. **BRISK+FREAK**: Standard Deviation = 2.37
   - High variability
   - Mean TTC = 11.23 seconds
   - Range: 5.64 - 14.82 seconds

5. **ORB+BRIEF**: Standard Deviation = 2.34
   - Inconsistent performance
   - Mean TTC = 10.89 seconds
   - Range: 7.03 - 14.99 seconds

### Frame-by-Frame Analysis

The frame-by-frame analysis reveals several important patterns:

1. **Trend Consistency**: Most combinations show a general decreasing trend in TTC values, which is expected as the vehicle approaches. However, some combinations (particularly the unstable ones) show erratic changes between frames.

2. **Outlier Frames**: Certain frames are more challenging for specific combinations:
   - BRISK+ORB shows extreme outliers in frames 7 and 15
   - ORB+FREAK shows significant drops in frames 9 and 16
   - AKAZE+BRISK shows an unusually low value in frame 12

3. **Stability Patterns**: The most stable combinations (FAST+BRIEF, AKAZE+AKAZE, SIFT+SIFT) maintain consistent TTC estimates across all frames, with smooth transitions between consecutive frames.

## Visualizations

We have created several visualizations to help analyze the performance:

1. **Interactive HTML Chart**: `visualize_ttc.html` provides an interactive visualization of all combinations, with the ability to compare specific combinations side-by-side.

2. **Spreadsheet View**: `ttc_spreadsheet.html` presents the data in a spreadsheet format with highlighting of minimum and maximum values for each frame.

3. **Individual Charts**: Individual charts for each combination are available in the `charts/` directory, showing the TTC trend over frames.

## Conclusion

Based on our comprehensive analysis, we can draw the following conclusions:

1. **Best Overall Combination**: FAST+BRIEF provides the best balance of stability and accuracy. It consistently produces reliable TTC estimates with minimal variation between frames.

2. **Best for Accuracy**: AKAZE+AKAZE and SIFT+SIFT provide very accurate TTC estimates that closely match the ground truth, though at a higher computational cost.

3. **Combinations to Avoid**: BRISK+ORB, AKAZE+BRISK, and BRISK+SIFT should be avoided due to their high variability and tendency to produce outliers.

4. **Performance vs. Speed Tradeoff**: While FAST+BRIEF offers the best stability, AKAZE+AKAZE and SIFT+SIFT may provide better accuracy in challenging scenarios at the cost of higher computation time.

5. **Detector Impact**: The choice of detector has a more significant impact on stability than the choice of descriptor. FAST and AKAZE detectors generally lead to more stable TTC estimates.

These findings satisfy the FP.6 requirement to compare different detector/descriptor combinations and analyze their performance on a frame-by-frame basis.

## Files Included

- `TTC_Performance_Eval2.csv`: Complete dataset with TTC values for all combinations across all frames
- `TTC_Performance_Summary.md`: Statistical summary of all combinations
- `visualize_ttc.html`: Interactive visualization of TTC data
- `ttc_spreadsheet.html`: Spreadsheet-like view of the data
- `TTC_Performance_Eval2.zip`: ZIP archive containing all files

This comprehensive evaluation provides all the necessary data and analysis to satisfy the FP.6 requirement of the project rubric.
