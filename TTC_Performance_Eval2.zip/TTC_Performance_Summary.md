# TTC Performance Evaluation Summary

## Detector/Descriptor Combinations

| Detector | Descriptor | Mean TTC | Std Dev | Min TTC | Max TTC |
|----------|------------|----------|---------|---------|--------|
| FAST | BRIEF | 11.66 | 0.99 | 9.42 | 13.20 |
| FAST | ORB | 10.08 | 1.25 | 7.56 | 12.86 |
| FAST | BRISK | 10.76 | 1.04 | 9.08 | 12.87 |
| FAST | FREAK | 9.98 | 1.44 | 7.44 | 13.34 |
| FAST | SIFT | 10.19 | 1.30 | 7.61 | 11.90 |
| BRISK | BRIEF | 8.92 | 1.84 | 6.35 | 12.50 |
| BRISK | ORB | 12.36 | 5.48 | 8.28 | 33.35 |
| BRISK | BRISK | 9.93 | 2.21 | 4.64 | 12.74 |
| BRISK | FREAK | 11.23 | 2.37 | 5.64 | 14.82 |
| BRISK | SIFT | 10.04 | 2.44 | 6.12 | 14.45 |
| ORB | BRIEF | 10.89 | 2.34 | 7.03 | 14.99 |
| ORB | ORB | 12.10 | 1.48 | 9.72 | 15.02 |
| ORB | BRISK | 10.82 | 1.57 | 7.35 | 14.15 |
| ORB | FREAK | 10.27 | 2.02 | 6.33 | 13.95 |
| ORB | SIFT | 9.08 | 1.82 | 5.51 | 13.34 |
| AKAZE | BRIEF | 10.06 | 1.45 | 7.47 | 13.47 |
| AKAZE | ORB | 11.91 | 1.35 | 10.09 | 15.34 |
| AKAZE | BRISK | 10.92 | 2.88 | 4.46 | 15.69 |
| AKAZE | FREAK | 10.45 | 1.39 | 7.82 | 13.02 |
| AKAZE | AKAZE | 11.53 | 1.17 | 9.64 | 13.89 |
| AKAZE | SIFT | 9.95 | 2.06 | 6.27 | 15.21 |
| SIFT | BRIEF | 9.38 | 1.60 | 5.71 | 12.52 |
| SIFT | ORB | 11.07 | 1.52 | 8.57 | 14.03 |
| SIFT | BRISK | 10.64 | 1.76 | 5.88 | 14.25 |
| SIFT | FREAK | 11.17 | 2.22 | 5.40 | 15.35 |
| SIFT | SIFT | 11.54 | 1.44 | 9.11 | 14.19 |
| SHITOMASI | BRIEF | 11.88 | 1.28 | 10.24 | 14.35 |
| SHITOMASI | ORB | 11.47 | 1.99 | 8.06 | 15.99 |
| SHITOMASI | BRISK | 9.32 | 2.09 | 5.62 | 13.89 |
| SHITOMASI | FREAK | 10.62 | 1.37 | 7.04 | 12.91 |
| SHITOMASI | SIFT | 10.05 | 1.04 | 7.66 | 12.33 |
| HARRIS | BRIEF | 10.61 | 1.15 | 8.57 | 12.84 |
| HARRIS | ORB | 9.30 | 1.48 | 6.59 | 12.36 |
| HARRIS | BRISK | 12.02 | 1.42 | 9.56 | 14.38 |
| HARRIS | FREAK | 10.42 | 1.72 | 6.96 | 13.72 |
| HARRIS | SIFT | 10.16 | 1.59 | 7.43 | 12.68 |

## Best Performing Combinations

Based on stability (lowest standard deviation):

1. **FAST+BRIEF**: Standard Deviation = 0.99
2. **FAST+BRISK**: Standard Deviation = 1.04
3. **SHITOMASI+SIFT**: Standard Deviation = 1.04
4. **HARRIS+BRIEF**: Standard Deviation = 1.15
5. **AKAZE+AKAZE**: Standard Deviation = 1.17

## Worst Performing Combinations

Based on instability (highest standard deviation):

1. **ORB+BRIEF**: Standard Deviation = 2.34
2. **BRISK+FREAK**: Standard Deviation = 2.37
3. **BRISK+SIFT**: Standard Deviation = 2.44
4. **AKAZE+BRISK**: Standard Deviation = 2.88
5. **BRISK+ORB**: Standard Deviation = 5.48
